package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.example.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class InvoiceSteps {

    private LocationManager locationManager = new LocationManager();
    private PricingManager pricingManager = new PricingManager();
    private ChargingSessionManager sessionManager = new ChargingSessionManager(locationManager, pricingManager);
    private InvoiceManager invoiceManager = new InvoiceManager();

    private Client client;
    private ChargingStation station;
    private Charger charger;
    private ChargingSession session;
    private Invoice invoice;
    private Exception lastException;

    @Given("a client with id {string} and prepaid balance {double}")
    public void a_client_with_id_and_prepaid_balance(String clientId, double balance) {
        client = new Client(clientId, "Invoice Client", clientId + "@example.com", "pwd");
        client.setPrepaidBalance(balance);
    }

    @Given("a station {string} with address {string} and an AC charger {string}")
    public void a_station_with_address_and_an_ac_charger(String name, String address, String chargerId) {
        station = locationManager.createStation(name, address);
        charger = locationManager.addChargerToStation(station.getStationId(), chargerId, ChargerType.AC, 11.0);
    }

    @Given("AC price {double} per kWh and {double} per minute is configured for that station")
    public void ac_price_per_kwh_and_per_minute_is_configured_for_that_station(double priceKwh, double priceMin) {
        pricingManager.updateAcDcPrices(station.getStationId(), ChargerType.AC, priceKwh, priceMin);
    }

    @When("the client completes a charging session of {double} kWh and {int} minutes on charger {string}")
    public void the_client_completes_a_charging_session_of_kwh_and_minutes_on_charger(double kwh, int minutes, String chargerId) {
        session = sessionManager.startSession(client, station.getStationId(), chargerId);
        session = sessionManager.stopSession(session.getSessionId(), kwh, minutes);

        double amount = session.getEnergyKwh() * session.getPricePerKwhAtStart()
                + session.getDurationMinutes() * session.getPricePerMinuteAtStart();

        try {
            invoice = invoiceManager.createInvoice(session, amount);
            lastException = null;
        } catch (Exception e) {
            lastException = e;
        }
    }

    @Then("an invoice should be created for this client")
    public void an_invoice_should_be_created_for_this_client() {
        assertNull(lastException, "Invoice creation should not throw exception");
        assertNotNull(invoice, "Invoice should not be null");
        assertEquals(client.getCustomerId(), invoice.getClientId(), "Invoice should belong to the client");
    }

    @Then("the client can review their invoices sorted by session start time")
    public void the_client_can_review_their_invoices_sorted_by_session_start_time() {
        List<Invoice> list = invoiceManager.getInvoicesForClient(client.getCustomerId());
        assertFalse(list.isEmpty(), "Client invoice list must not be empty");
        // einfacher Sortiercheck: Startzeiten sind nicht absteigend
        for (int i = 1; i < list.size(); i++) {
            assertTrue(!list.get(i).getSessionStart().isBefore(list.get(i - 1).getSessionStart()),
                    "Invoices should be sorted by session start time");
        }
    }

    // ------------ O4: Invoice bearbeiten / stornieren ------------

    @When("the owner edits the invoice amount to {double} with reason {string}")
    public void the_owner_edits_the_invoice_amount_to_with_reason(double newAmount, String reason) {
        try {
            invoice = invoiceManager.editInvoice(invoice.getInvoiceId(),
                    invoice.getEnergyKwh(),
                    invoice.getDurationMinutes(),
                    newAmount,
                    reason);
            lastException = null;
        } catch (Exception e) {
            lastException = e;
        }
    }

    @Then("the invoice amount should be {double}")
    public void the_invoice_amount_should_be(double expectedAmount) {
        assertNull(lastException, "Edit should not throw exception");
        assertEquals(expectedAmount, invoice.getAmount(), 0.0001);
    }

    @When("the owner cancels the invoice with reason {string}")
    public void the_owner_cancels_the_invoice_with_reason(String reason) {
        try {
            invoice = invoiceManager.cancelInvoice(invoice.getInvoiceId(), reason);
            lastException = null;
        } catch (Exception e) {
            lastException = e;
        }
    }

    @Then("the invoice should be marked as cancelled")
    public void the_invoice_should_be_marked_as_cancelled() {
        assertNull(lastException, "Cancel should not throw exception");
        assertTrue(invoice.isCancelled(), "Invoice should be cancelled");
        assertFalse(invoice.getChangeLog().isEmpty(), "Change log should contain cancel entry");
    }

    @Then("generating a PDF for the invoice should succeed")
    public void generating_a_pdf_for_the_invoice_should_succeed() {
        byte[] pdf = invoiceManager.generateInvoicePdf(invoice.getInvoiceId());
        assertNotNull(pdf);
        assertTrue(pdf.length > 0, "PDF byte array should not be empty");
    }

    @Then("the owner can view all invoices")
    public void the_owner_can_view_all_invoices() {
        List<Invoice> all = invoiceManager.getAllInvoices();
        assertNotNull(all, "Invoice list must not be null");
        assertFalse(all.isEmpty(), "There should be at least one invoice");
    }

    @Then("the owner can see the invoice details including amount energy duration and session reference")
    public void the_owner_can_see_the_invoice_details_including_amount_energy_duration_and_session_reference() {
        assertNotNull(invoice, "Invoice must not be null");
        assertTrue(invoice.getAmount() > 0, "Amount should be > 0");
        assertTrue(invoice.getEnergyKwh() > 0, "Energy should be > 0");
        assertTrue(invoice.getDurationMinutes() > 0, "Duration should be > 0");
        assertNotNull(invoice.getSessionId(), "Session ID should not be null");
    }

    @Then("the invoice change log should contain the reason {string}")
    public void the_invoice_change_log_should_contain_the_reason(String reason) {
        assertNotNull(invoice, "Invoice must not be null");
        boolean contains = invoice.getChangeLog().stream()
                .anyMatch(entry -> entry.contains(reason));
        assertTrue(contains, "Change log should contain reason: " + reason);
    }
}