package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import org.example.*;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

public class OwnerLocationAndPricingSteps {

    private LocationManager locationManager;
    private PricingManager pricingManager;
    private ChargingSessionManager sessionManager;

    private ChargingStation lastStation;
    private Charger lastCharger;
    private Client testClient;

    private List<LocationManager.StationSearchResult> lastSearchResults;
    private List<ChargingSessionManager.StationStatusSummary> lastStatusDashboard;
    private List<ChargingSessionManager.StationWorkload> lastWorkload;
    private ChargingSession lastSession;
    private Exception lastException;

    private Exception lastLocationException;
    private int previousStationVersion;



    @Given("an empty station network")
    public void an_empty_station_network() {
        locationManager = new LocationManager();
        pricingManager = new PricingManager();
        sessionManager = new ChargingSessionManager(locationManager, pricingManager);
    }

    // ------------------- O1: Station & Charger -------------------

    @When("the owner creates a station {string} at {string}")
    public void the_owner_creates_a_station_at(String name, String address) {
        lastStation = locationManager.createStation(name, address);
    }

    @And("the owner adds a charger {string} of type {string} with power {double} kW to this station")
    public void the_owner_adds_a_charger_of_type_with_power_to_this_station(String chargerId, String type, double power) {
        assertNotNull(lastStation, "Station must exist before adding a charger");
        ChargerType chargerType = ChargerType.valueOf(type);
        lastCharger = locationManager.addChargerToStation(lastStation.getStationId(), chargerId, chargerType, power);
    }

    @Then("the station should be listed with name {string}")
    public void the_station_should_be_listed_with_name(String expectedName) {
        boolean found = locationManager.getAllStations().stream()
                .anyMatch(s -> s.getName().equals(expectedName));
        assertTrue(found, "Station with name " + expectedName + " should be listed");
    }

    @Then("the charger {string} should exist with status {string}")
    public void the_charger_should_exist_with_status(String chargerId, String expectedStatus) {
        Optional<Charger> chargerOpt = locationManager.getCharger(chargerId);
        assertTrue(chargerOpt.isPresent(), "Charger " + chargerId + " should exist");
        Charger charger = chargerOpt.get();
        assertEquals(ChargerStatus.valueOf(expectedStatus), charger.getStatus());
    }

    // ------------------- C2.1: Search Stations -------------------

    @When("a client searches for stations with text {string}")
    public void a_client_searches_for_stations_with_text(String text) {
        lastSearchResults = locationManager.searchStationsByText(text);
    }

    @Then("the search results should contain a station named {string}")
    public void the_search_results_should_contain_a_station_named(String expectedName) {
        assertNotNull(lastSearchResults, "Search results must not be null");
        boolean found = lastSearchResults.stream()
                .anyMatch(r -> r.name.equals(expectedName));
        assertTrue(found, "Search results should contain station named " + expectedName);
    }

    // ------------------- O2: Preise setzen -------------------

    @And("the owner sets AC price to {double} per kWh and {double} per minute for this station")
    public void the_owner_sets_ac_price_to_per_kwh_and_per_minute_for_this_station(double priceKwh, double priceMin) {
        assertNotNull(lastStation, "Station must exist");
        pricingManager.updateAcDcPrices(lastStation.getStationId(), ChargerType.AC, priceKwh, priceMin);
    }

    @And("the owner sets DC price to {double} per kWh and {double} per minute for this station")
    public void the_owner_sets_dc_price_to_per_kwh_and_per_minute_for_this_station(double priceKwh, double priceMin) {
        assertNotNull(lastStation, "Station must exist");
        pricingManager.updateAcDcPrices(lastStation.getStationId(), ChargerType.DC, priceKwh, priceMin);
    }

    @Then("the AC price per kWh for this station should be {double}")
    public void the_ac_price_per_kwh_for_this_station_should_be(double expectedPrice) {
        StationPricing pricing = pricingManager.getPricingForStation(lastStation.getStationId());
        double actual = pricing.getEnergyPrice(ChargerType.AC)
                .orElseThrow(() -> new AssertionError("AC price not configured"))
                .getPricePerKwh();
        assertEquals(expectedPrice, actual, 0.0001);
    }

    @And("the owner configures duration price rules for this station")
    public void the_owner_configures_duration_price_rules_for_this_station() {
        assertNotNull(lastStation, "Station must exist");
        DurationPriceRule rule1 = new DurationPriceRule(0, 60, 0.1);
        DurationPriceRule rule2 = new DurationPriceRule(60, 180, 0.3);
        pricingManager.updateDurationPrices(lastStation.getStationId(), List.of(rule1, rule2));
    }

    @Then("the station should have at least {int} duration price rule")
    public void the_station_should_have_at_least_duration_price_rule(int minRules) {
        StationPricing pricing = pricingManager.getPricingForStation(lastStation.getStationId());
        int size = pricing.getDurationPriceRulesSnapshot().size();
        assertTrue(size >= minRules, "Expected at least " + minRules + " rules but got " + size);
    }

    // ------------------- C2.2 + O3: Session & Monitoring -------------------

    @Given("a test client with id {string} and prepaid balance {double}")
    public void a_test_client_with_id_and_prepaid_balance(String clientId, double balance) {
        testClient = new Client(clientId, "Test Client", clientId + "@example.com", "pwd");
        testClient.setPrepaidBalance(balance);
    }

    @When("the client starts a charging session at this station using charger {string}")
    public void the_client_starts_a_charging_session_at_this_station_using_charger(String chargerId) {
        try {
            lastSession = sessionManager.startSession(testClient, lastStation.getStationId(), chargerId);
            lastException = null;
        } catch (Exception e) {
            lastSession = null;
            lastException = e;
        }
    }
    @And("the session is stopped with {double} kWh and {int} minutes")
    public void the_session_is_stopped_with_kwh_and_minutes(double kwh, int minutes) {
        assertNotNull(lastSession, "Session must exist");
        lastSession = sessionManager.stopSession(lastSession.getSessionId(), kwh, minutes);
        assertFalse(lastSession.isActive(), "Session should be inactive after stopping");
    }

    @When("the owner views the station status dashboard")
    public void the_owner_views_the_station_status_dashboard() {
        lastStatusDashboard = sessionManager.getStationStatusDashboard();
    }

    @Then("the dashboard shows charger {string} with status {string}")
    public void the_dashboard_shows_charger_with_status(String chargerId, String expectedStatus) {
        assertNotNull(lastStatusDashboard, "Dashboard must not be null");
        boolean found = lastStatusDashboard.stream()
                .filter(s -> s.stationId.equals(lastStation.getStationId()))
                .flatMap(s -> s.chargerStatuses.stream())
                .anyMatch(info -> info.equals(chargerId + ": " + ChargerStatus.valueOf(expectedStatus)));
        assertTrue(found, "Dashboard should show " + chargerId + " with status " + expectedStatus);
    }

    @When("the owner views the realtime workload")
    public void the_owner_views_the_realtime_workload() {
        lastWorkload = sessionManager.getRealtimeWorkload();
    }

    @Then("the workload for this station shows {int} active sessions")
    public void the_workload_for_this_station_shows_active_sessions(int expectedActive) {
        assertNotNull(lastWorkload, "Workload must not be null");
        ChargingSessionManager.StationWorkload workload = lastWorkload.stream()
                .filter(w -> w.stationId.equals(lastStation.getStationId()))
                .findFirst()
                .orElseThrow(() -> new AssertionError("Workload for station not found"));
        assertEquals(expectedActive, workload.activeSessions, "Active session count mismatch");
    }

    @Then("the search results should show charger {string} with type {string} and its current status")
    public void the_search_results_should_show_charger_with_type_and_its_current_status(String chargerId, String type) {
        assertNotNull(lastSearchResults, "Search results must not be null");

        boolean found = lastSearchResults.stream()
                .flatMap(r -> r.chargerSummaries.stream())
                .anyMatch(summary ->
                        summary.contains(chargerId) &&
                                summary.contains(type)
                );

        assertTrue(found, "Expected charger " + chargerId + " with type " + type + " in search results");
    }

    @Then("no stations should be returned")
    public void no_stations_should_be_returned() {
        assertNotNull(lastSearchResults, "Search results must not be null");
        assertTrue(lastSearchResults.isEmpty(), "Expected no stations in search results");
    }

    @Then("the session should be active")
    public void the_session_should_be_active() {
        assertNotNull(lastSession, "Session must not be null");
        assertTrue(lastSession.isActive(), "Session should be active");
    }

    @Then("the session should log a start time")
    public void the_session_should_log_a_start_time() {
        assertNotNull(lastSession, "Session must not be null");
        assertNotNull(lastSession.getStartTime(), "Start time must not be null");
    }

    @Then("the session should store the charging mode as {string}")
    public void the_session_should_store_the_charging_mode_as(String mode) {
        assertNotNull(lastSession, "Session must not be null");
        assertEquals(ChargerType.valueOf(mode), lastSession.getChargerTypeAtStart());
    }

    @Then("the session start should fail due to insufficient balance")
    public void the_session_start_should_fail_due_to_insufficient_balance() {
        assertNotNull(lastException, "Expected an exception due to insufficient balance");
    }

    @When("the owner tries to add a charger {string} of type {string} with power {double} kW to this station")
    public void the_owner_tries_to_add_a_charger_of_type_with_power_k_w_to_this_station(String chargerId, String type, Double power) {
        try {
            ChargerType chargerType = ChargerType.valueOf(type);
            lastCharger = locationManager.addChargerToStation(lastStation.getStationId(), chargerId, chargerType, power);
            lastLocationException = null;
        } catch (Exception e) {
            lastCharger = null;
            lastLocationException = e;
        }
    }

    @Then("the charger creation should fail")
    public void the_charger_creation_should_fail() {
        assertNotNull(lastLocationException, "Expected charger creation to fail");
    }

    @When("the owner updates the station name to {string} and address to {string}")
    public void the_owner_updates_the_station_name_to_and_address_to(String newName, String newAddress) {
        assertNotNull(lastStation, "Station must exist");
        previousStationVersion = lastStation.getVersion();
        locationManager.updateStation(lastStation.getStationId(), newName, newAddress);
        lastStation = locationManager.getStation(lastStation.getStationId())
                .orElseThrow(() -> new AssertionError("Updated station not found"));
    }

    @Then("the station version should be increased")
    public void the_station_version_should_be_increased() {
        assertTrue(lastStation.getVersion() > previousStationVersion, "Station version should be increased");
    }

    @When("the owner updates charger {string} to type {string} power {double} kW and status {string}")
    public void the_owner_updates_charger_to_type_power_k_w_and_status(String chargerId, String type, Double power, String status) {
        ChargerType chargerType = ChargerType.valueOf(type);
        ChargerStatus chargerStatus = ChargerStatus.valueOf(status);
        locationManager.updateCharger(chargerId, chargerType, power, chargerStatus);
        lastCharger = locationManager.getCharger(chargerId)
                .orElseThrow(() -> new AssertionError("Updated charger not found"));
    }

    @When("the owner deletes this station and no active sessions exist")
    public void the_owner_deletes_this_station_and_no_active_sessions_exist() {
        assertNotNull(lastStation, "Station must exist");
        boolean deleted = locationManager.deleteStation(lastStation.getStationId());
        assertTrue(deleted, "Station should be deleted when no active sessions exist");
    }

    @Then("the station should be removed from the overview")
    public void the_station_should_be_removed_from_the_overview() {
        boolean stillThere = locationManager.getAllStations().stream()
                .anyMatch(s -> s.getStationId().equals(lastStation.getStationId()));
        assertFalse(stillThere, "Station should not be listed anymore");
    }

    @When("the owner tries to delete this station")
    public void the_owner_tries_to_delete_this_station() {
        try {
            boolean deleted = locationManager.deleteStation(lastStation.getStationId());
            if (deleted) {
                lastLocationException = null;
            }
        } catch (Exception e) {
            lastLocationException = e;
        }
    }

    @Then("the station deletion should fail")
    public void the_station_deletion_should_fail() {
        if (lastLocationException != null) {
            return;
        }
        boolean stillThere = locationManager.getAllStations().stream()
                .anyMatch(s -> s.getStationId().equals(lastStation.getStationId()));
        assertTrue(stillThere, "Station should still exist when active sessions are present");
    }


    @When("the owner deletes the charger {string} without active sessions")
    public void the_owner_deletes_the_charger_without_active_sessions(String chargerId) {
        boolean deleted = locationManager.deleteCharger(chargerId);
        assertTrue(deleted, "Charger should be deleted when no active sessions exist");
    }


    @When("the owner tries to delete the charger {string}")
    public void the_owner_tries_to_delete_the_charger(String chargerId) {
        try {
            locationManager.deleteCharger(chargerId);
            lastException = null;
        } catch (Exception e) {
            lastException = e;
        }
    }

    @Then("the charger deletion should fail")
    public void the_charger_deletion_should_fail() {
        assertNotNull(lastException, "Expected deletion to fail due to active sessions");
    }

    @Then("the charger {string} should no longer exist")
    public void the_charger_should_no_longer_exist(String chargerId) {
        boolean stillThere = locationManager.getCharger(chargerId).isPresent();
        assertFalse(stillThere, "Charger should not exist anymore");
    }




    @When("the owner requests information for charger {string}")
    public void the_owner_requests_information_for_charger(String chargerId) {
        lastCharger = locationManager.getCharger(chargerId)
                .orElseThrow(() -> new AssertionError("Charger not found: " + chargerId));
    }

    @Then("the system shows the charger id type status and power level")
    public void the_system_shows_the_charger_id_type_status_and_power_level() {
        assertNotNull(lastCharger, "Charger must not be null");
        assertNotNull(lastCharger.getChargerId());
        assertNotNull(lastCharger.getType());
        assertNotNull(lastCharger.getStatus());

    }

    @When("the owner requests information for station {string}")
    public void the_owner_requests_information_for_station(String stationName) {
        lastStation = locationManager.getAllStations().stream()
                .filter(s -> s.getName().equals(stationName))
                .findFirst()
                .orElseThrow(() -> new AssertionError("Station not found: " + stationName));
    }


    @Then("the system shows station name address and its associated chargers")
    public void the_system_shows_station_name_address_and_its_associated_chargers() {
        assertNotNull(lastStation.getName());
        assertNotNull(lastStation.getAddress());

        java.util.Map<String, Charger> chargers = lastStation.getChargers();
        assertNotNull(chargers, "Chargers map must not be null");
        assertFalse(chargers.isEmpty(), "Station should have associated chargers");
    }
    @Given("the station {string} has active sessions")
    public void the_station_has_active_sessions(String stationName) {
        assertNotNull(lastStation, "Station must exist");
        lastStation.setHasActiveSessions(true);
    }

    @Given("the charger {string} has active sessions")
    public void the_charger_has_active_sessions(String chargerId) {
        // Flag im LocationManager setzen, statt echte Session zu starten
        locationManager.markChargerHasActiveSessions(chargerId, true);

        lastCharger = locationManager.getCharger(chargerId)
                .orElseThrow(() -> new AssertionError("Charger not found: " + chargerId));
    }

    @Then("the session should use the original price per kWh {double} and per minute {double}")
    public void the_session_should_use_the_original_price_per_k_wh_and_per_minute(Double expectedKwh, Double expectedMinute) {
        assertNotNull(lastSession, "Session must not be null");
        assertEquals(expectedKwh, lastSession.getPricePerKwhAtStart());
        assertEquals(expectedMinute, lastSession.getPricePerMinuteAtStart());
    }
}