package org.example;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PricingManager {

    private final Map<String, StationPricing> pricingByStationId = new HashMap<>();

    private StationPricing getOrCreatePricing(String stationId) {
        return pricingByStationId.computeIfAbsent(stationId, id -> new StationPricing());
    }

    /*US-O2.1: Update AC/DC Prices Preise können mehrfach pro Tag geändert werden.*/

    public void updateAcDcPrices(String stationId, ChargerType type, double pricePerKwh, double pricePerMinute) {
        if (stationId == null || stationId.isBlank()) {
            throw new IllegalArgumentException("stationId is required");}
        StationPricing pricing = getOrCreatePricing(stationId);
        pricing.setEnergyPrice(type, pricePerKwh, pricePerMinute);}

    /*US-O2.2: Update Duration Prices*/
    public void updateDurationPrices(String stationId, List<DurationPriceRule> rules) {
        if (stationId == null || stationId.isBlank()) {
            throw new IllegalArgumentException("stationId is required");}
        StationPricing pricing = getOrCreatePricing(stationId);
        pricing.setDurationPriceRules(rules);}

    public StationPricing getPricingForStation(String stationId) {
        return pricingByStationId.getOrDefault(stationId, new StationPricing());
    }
}