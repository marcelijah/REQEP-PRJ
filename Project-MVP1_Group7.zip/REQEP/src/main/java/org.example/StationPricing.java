package org.example;

import java.util.*;

public class StationPricing {

    private final Map<ChargerType, EnergyPrice> energyPrices = new EnumMap<>(ChargerType.class);
    private List<DurationPriceRule> durationPriceRules = new ArrayList<>();

    public void setEnergyPrice(ChargerType type, double pricePerKwh, double pricePerMinute) {
        if (type == null) throw new IllegalArgumentException("type is required");
        energyPrices.put(type, new EnergyPrice(pricePerKwh, pricePerMinute));
    }

    public Optional<EnergyPrice> getEnergyPrice(ChargerType type) {
        return Optional.ofNullable(energyPrices.get(type));
    }

    public void setDurationPriceRules(List<DurationPriceRule> rules) {
        if (rules == null) {
            this.durationPriceRules = new ArrayList<>();
        } else {
            this.durationPriceRules = new ArrayList<>(rules);
        }
    }

    public List<DurationPriceRule> getDurationPriceRulesSnapshot() {
        return new ArrayList<>(durationPriceRules);
    }
}