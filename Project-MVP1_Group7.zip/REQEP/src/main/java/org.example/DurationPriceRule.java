package org.example;

public class DurationPriceRule {

    private final int fromMinuteInclusive;
    private final int toMinuteExclusive;
    private final double pricePerMinute;

    public DurationPriceRule(int fromMinuteInclusive, int toMinuteExclusive, double pricePerMinute) {
        if (fromMinuteInclusive < 0 || toMinuteExclusive <= fromMinuteInclusive) {
            throw new IllegalArgumentException("Invalid minute range");
        }
        if (pricePerMinute < 0) {
            throw new IllegalArgumentException("Price must be non-negative");
        }
        this.fromMinuteInclusive = fromMinuteInclusive;
        this.toMinuteExclusive = toMinuteExclusive;
        this.pricePerMinute = pricePerMinute;
    }

    public int getFromMinuteInclusive() {
        return fromMinuteInclusive;
    }

    public int getToMinuteExclusive() {
        return toMinuteExclusive;
    }

    public double getPricePerMinute() {
        return pricePerMinute;
    }
}