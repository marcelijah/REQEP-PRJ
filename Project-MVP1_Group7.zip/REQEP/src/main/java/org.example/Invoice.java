package org.example;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Invoice {

    private final String invoiceId;
    private final String sessionId;
    private final String clientId;
    private final String stationId;
    private final String chargerId;

    private final LocalDateTime sessionStart;
    private final LocalDateTime sessionEnd;

    private double energyKwh;
    private int durationMinutes;
    private double amount;

    private boolean cancelled;
    private int version;
    private final List<String> changeLog = new ArrayList<>();

    public Invoice(String invoiceId,
                   ChargingSession session,
                   double amount) {

        this.invoiceId = invoiceId;
        this.sessionId = session.getSessionId();
        this.clientId = session.getClientId();
        this.stationId = session.getStationId();
        this.chargerId = session.getChargerId();
        this.sessionStart = session.getStartTime();
        this.sessionEnd = session.getEndTime();
        this.energyKwh = session.getEnergyKwh();
        this.durationMinutes = session.getDurationMinutes();
        this.amount = amount;
        this.version = 1;
    }

    public String getInvoiceId() {
        return invoiceId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getClientId() {
        return clientId;
    }

    public String getStationId() {
        return stationId;
    }

    public String getChargerId() {
        return chargerId;
    }

    public LocalDateTime getSessionStart() {
        return sessionStart;
    }

    public LocalDateTime getSessionEnd() {
        return sessionEnd;
    }

    public double getEnergyKwh() {
        return energyKwh;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public double getAmount() {
        return amount;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public int getVersion() {
        return version;
    }


    public List<String> getChangeLog() {
        return new ArrayList<>(changeLog);
    }

    // Wird vom InvoiceManager benutzt
    void applyEdit(double newEnergyKwh, int newDurationMinutes, double newAmount, String reason) {
        this.energyKwh = newEnergyKwh;
        this.durationMinutes = newDurationMinutes;
        this.amount = newAmount;
        this.version++;
        this.changeLog.add("v" + version + ": " + reason);
    }

    // Wird vom InvoiceManager benutzt
    void cancel(String reason) {
        this.cancelled = true;
        this.version++;
        this.changeLog.add("cancelled: " + reason);
    }
}