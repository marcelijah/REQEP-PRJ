package org.example;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class ChargingSessionManager {

    private final LocationManager locationManager;
    private final PricingManager pricingManager;

    private final Map<String, ChargingSession> sessionsById = new HashMap<>();

    public ChargingSessionManager(LocationManager locationManager, PricingManager pricingManager) {
        this.locationManager = locationManager;
        this.pricingManager = pricingManager;
    }

    private String generateSessionId() {
        return "SES-" + UUID.randomUUID();
    }

    /**
     * US-C2.2: Start Charging Station
     * - Prepaid balance is checked
     * - Session logs start time and charging mode
     */
    public ChargingSession startSession(Client client, String stationId, String chargerId) {
        if (client.getPrepaidBalance() <= 0) {
            throw new IllegalStateException("Insufficient prepaid balance");
        }

        ChargingStation station = locationManager.getStation(stationId)
                .orElseThrow(() -> new IllegalArgumentException("Station not found"));

        Charger charger = station.getChargers().get(chargerId);
        if (charger == null) {
            throw new IllegalArgumentException("Charger not found at station");
        }

        if (charger.getStatus() != ChargerStatus.OPERATIONAL_FREE) {
            throw new IllegalStateException("Charger is not free");
        }

        StationPricing pricing = pricingManager.getPricingForStation(stationId);
        EnergyPrice energyPrice = pricing.getEnergyPrice(charger.getType())
                .orElseThrow(() -> new IllegalStateException("No price configured for charger type"));

        List<DurationPriceRule> durationRulesSnapshot = pricing.getDurationPriceRulesSnapshot();

        LocalDateTime now = LocalDateTime.now();
        String sessionId = generateSessionId();

        ChargingSession session = new ChargingSession(
                sessionId,
                stationId,
                chargerId,
                client.getCustomerId(),
                now,
                charger.getType(),
                energyPrice.getPricePerKwh(),
                energyPrice.getPricePerMinute(),
                durationRulesSnapshot
        );

        sessionsById.put(sessionId, session);

        // Charger belegen (für O3.1)
        charger.setStatus(ChargerStatus.OPERATIONAL_OCCUPIED);

        return session;
    }

    /**
     * Session beenden, Verbrauch setzen, Charger wieder frei.
     * (wird später für Invoice benötigt)
     */
    public ChargingSession stopSession(String sessionId, double energyKwh, int durationMinutes) {
        ChargingSession session = sessionsById.get(sessionId);
        if (session == null) {
            throw new IllegalArgumentException("Session not found");
        }
        if (!session.isActive()) {
            throw new IllegalStateException("Session already stopped");
        }

        ChargingStation station = locationManager.getStation(session.getStationId())
                .orElseThrow(() -> new IllegalArgumentException("Station not found"));

        Charger charger = station.getChargers().get(session.getChargerId());
        if (charger != null && charger.getStatus() == ChargerStatus.OPERATIONAL_OCCUPIED) {
            charger.setStatus(ChargerStatus.OPERATIONAL_FREE);
        }

        session.stop(LocalDateTime.now(), energyKwh, durationMinutes);
        return session;
    }

    public Optional<ChargingSession> getSession(String sessionId) {
        return Optional.ofNullable(sessionsById.get(sessionId));
    }

    public List<ChargingSession> getActiveSessions() {
        return sessionsById.values()
                .stream()
                .filter(ChargingSession::isActive)
                .collect(Collectors.toList());
    }

    public List<ChargingSession> getSessionsForStation(String stationId) {
        return sessionsById.values()
                .stream()
                .filter(s -> s.getStationId().equals(stationId))
                .collect(Collectors.toList());
    }

    // ---------- EPIC O3: Monitoring ----------

    public static class StationStatusSummary {
        public final String stationId;
        public final String name;
        public final String address;
        public final List<String> chargerStatuses;

        public StationStatusSummary(String stationId, String name, String address, List<String> chargerStatuses) {
            this.stationId = stationId;
            this.name = name;
            this.address = address;
            this.chargerStatuses = chargerStatuses;
        }
    }

    public static class StationWorkload {
        public final String stationId;
        public final String name;
        public final int totalChargers;
        public final int activeSessions;
        public final double utilization; // activeSessions / totalChargers

        public StationWorkload(String stationId, String name, int totalChargers, int activeSessions) {
            this.stationId = stationId;
            this.name = name;
            this.totalChargers = totalChargers;
            this.activeSessions = activeSessions;
            this.utilization = totalChargers == 0 ? 0.0 : (double) activeSessions / totalChargers;
        }
    }

    /**
     * US-O3.1: Monitor Charging Station Status
     * - Status (free/occupied/out of order)
     */
    public List<StationStatusSummary> getStationStatusDashboard() {
        return locationManager.getAllStations().stream()
                .map(station -> {
                    List<String> chargerInfos = station.getChargers().values().stream()
                            .map(c -> c.getChargerId() + ": " + c.getStatus())
                            .collect(Collectors.toList());
                    return new StationStatusSummary(
                            station.getStationId(),
                            station.getName(),
                            station.getAddress(),
                            chargerInfos
                    );
                })
                .collect(Collectors.toList());
    }

    /**
     * US-O3.2: Monitor Realtime Workload
     * - Anzahl aktiver Sessions & Auslastung pro Standort
     */
    public List<StationWorkload> getRealtimeWorkload() {
        Map<String, Long> activeSessionsByStation = getActiveSessions().stream()
                .collect(Collectors.groupingBy(ChargingSession::getStationId, Collectors.counting()));

        return locationManager.getAllStations().stream()
                .map(station -> {
                    int totalChargers = station.getChargers().size();
                    int active = activeSessionsByStation.getOrDefault(station.getStationId(), 0L).intValue();
                    return new StationWorkload(station.getStationId(), station.getName(), totalChargers, active);
                })
                .collect(Collectors.toList());
    }
}