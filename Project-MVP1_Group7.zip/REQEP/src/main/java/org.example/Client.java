package org.example;

import java.util.Objects;

public class Client {

    private final String customerId;
    private String name;
    private String email;
    private String password;

    public Client(String customerId, String name, String email, String password) {
        if (customerId == null || customerId.isBlank()) {
            throw new IllegalArgumentException("customerId is required");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("name is required");
        }
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("email is required");
        }
        if (password == null || password.isBlank()) {
            throw new IllegalArgumentException("password is required");
        }
        this.customerId = customerId;
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("name is required");
        }
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("email is required");
        }
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (password == null || password.isBlank()) {
            throw new IllegalArgumentException("password is required");
        }
        this.password = password;
    }

    private double prepaidBalance;

    public double getPrepaidBalance() {
        return prepaidBalance;
    }

    public void setPrepaidBalance(double prepaidBalance) {
        if (prepaidBalance < 0) {
            throw new IllegalArgumentException("Prepaid balance cannot be negative");
        }
        this.prepaidBalance = prepaidBalance;
    }

    public void addToPrepaidBalance(double amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        this.prepaidBalance += amount;
    }

    public void deductFromPrepaidBalance(double amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        if (amount > this.prepaidBalance) {
            throw new IllegalStateException("Insufficient prepaid balance");
        }
        this.prepaidBalance -= amount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Client)) return false;
        Client client = (Client) o;
        return customerId.equals(client.customerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerId);
    }
}