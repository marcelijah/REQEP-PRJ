package org.example;

import java.util.*;
import java.util.stream.Collectors;

public class InvoiceManager {

    private final Map<String, Invoice> invoicesById = new HashMap<>();
    private final Map<String, List<String>> invoiceIdsByClientId = new HashMap<>();

    private String generateInvoiceId() {
        return "INV-" + UUID.randomUUID();
    }

    /**
     * Aus einem abgeschlossenen ChargingSession-Objekt eine Rechnung generieren.
     */
    public Invoice createInvoice(ChargingSession session, double amount) {
        if (session.isActive()) {
            throw new IllegalStateException("Session must be finished before invoicing");
        }

        String invoiceId = generateInvoiceId();
        Invoice invoice = new Invoice(invoiceId, session, amount);

        invoicesById.put(invoiceId, invoice);
        invoiceIdsByClientId
                .computeIfAbsent(invoice.getClientId(), id -> new ArrayList<>())
                .add(invoiceId);

        return invoice;
    }

    public Optional<Invoice> getInvoice(String invoiceId) {
        return Optional.ofNullable(invoicesById.get(invoiceId));
    }

    /**
     * US-C3.1: Review Created Invoices (Client)
     * - sortiert nach Session-Startzeit
     */
    public List<Invoice> getInvoicesForClient(String clientId) {
        List<String> ids = invoiceIdsByClientId.getOrDefault(clientId, Collections.emptyList());
        return ids.stream()
                .map(invoicesById::get)
                .filter(Objects::nonNull)
                .sorted(Comparator.comparing(Invoice::getSessionStart))
                .collect(Collectors.toList());
    }

    /**
     * US-O4.1: Review / Edit / Correct invoices (Owner)
     */
    public List<Invoice> getAllInvoices() {
        return new ArrayList<>(invoicesById.values());
    }

    public Invoice editInvoice(String invoiceId, double newEnergyKwh, int newDurationMinutes, double newAmount, String reason) {
        Invoice invoice = invoicesById.get(invoiceId);
        if (invoice == null) {
            throw new IllegalArgumentException("Invoice not found");
        }
        if (invoice.isCancelled()) {
            throw new IllegalStateException("Cancelled invoices cannot be edited");
        }
        invoice.applyEdit(newEnergyKwh, newDurationMinutes, newAmount, reason);
        return invoice;
    }

    public Invoice cancelInvoice(String invoiceId, String reason) {
        Invoice invoice = invoicesById.get(invoiceId);
        if (invoice == null) {
            throw new IllegalArgumentException("Invoice not found");
        }
        invoice.cancel(reason);
        return invoice;
    }

    public byte[] generateInvoicePdf(String invoiceId) {
        Invoice invoice = invoicesById.get(invoiceId);
        if (invoice == null) {
            throw new IllegalArgumentException("Invoice not found");
        }
        String content = "Invoice " + invoice.getInvoiceId()
                + " for client " + invoice.getClientId()
                + " amount " + invoice.getAmount();
        return content.getBytes();
    }
}