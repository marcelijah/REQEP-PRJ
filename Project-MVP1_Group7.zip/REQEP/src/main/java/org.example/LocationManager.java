package org.example;

import java.util.*;
import java.util.stream.Collectors;

public class LocationManager {

    private final Map<String, ChargingStation> stationsById = new HashMap<>();
    private final Set<String> chargerIds = new HashSet<>();

    private final Map<String, Charger> chargers = new HashMap<>();

    // einfache Simulation, ob aktive Sessions laufen
    private final Set<String> stationsWithActiveSessions = new HashSet<>();
    private final Set<String> chargersWithActiveSessions = new HashSet<>();

    private String generateStationId() {
        return "S-" + UUID.randomUUID();
    }

    /**
     * US-O1.1: Create New Charging Stations
     * - Each site has a name and address, visible in overview.
     */
    public ChargingStation createStation(String name, String address) {
        if (name == null || name.isBlank() || address == null || address.isBlank()) {
            throw new IllegalArgumentException("name and address are required");
        }
        String id = generateStationId();
        ChargingStation station = new ChargingStation(id, name, address);
        stationsById.put(id, station);
        return station;
    }

    /**
     * US-O1.8: Read Charging Station Information
     */
    public Optional<ChargingStation> getStation(String stationId) {
        return Optional.ofNullable(stationsById.get(stationId));
    }

    public List<ChargingStation> getAllStations() {
        return new ArrayList<>(stationsById.values());
    }

    /**
     * US-O1.3: Update Charging Stations (version-tracked durch ChargingStation)
     */
    public ChargingStation updateStation(String stationId, String newName, String newAddress) {
        ChargingStation station = stationsById.get(stationId);
        if (station == null) {
            throw new IllegalArgumentException("Station not found");
        }
        if (newName != null && !newName.isBlank()) {
            station.setName(newName);
        }
        if (newAddress != null && !newAddress.isBlank()) {
            station.setAddress(newAddress);
        }
        return station;
    }

    /**
     * US-O1.5: Delete Charging Stations
     * - Only allowed if no active sessions
     */

    public boolean deleteStation(String stationId) {
        ChargingStation station = stationsById.get(stationId);
        if (station == null) {
            return false;
        }

        boolean chargerHasActive = station.getChargers().values().stream()
                .anyMatch(Charger::hasActiveSessions);

        if (station.hasActiveSessions() || chargerHasActive) {
            return false;
        }

        stationsById.remove(stationId);
        return true;
    }

    /**
     * Hilfs-API für Tests, um aktive Sessions zu simulieren.
     */
    public void markStationHasActiveSessions(String stationId, boolean hasActive) {
        if (hasActive) {
            stationsWithActiveSessions.add(stationId);
        } else {
            stationsWithActiveSessions.remove(stationId);
        }
    }

    /**
     * US-O1.2: Create New Chargers
     * - Charger ID is unique, initial state is "operational – free".
     */
    public Charger addChargerToStation(String stationId, String chargerId, ChargerType type, double powerLevelKw) {
        ChargingStation station = stationsById.get(stationId);
        if (station == null) {
            throw new IllegalArgumentException("Station not found");
        }
        if (chargerId == null || chargerId.isBlank()) {
            throw new IllegalArgumentException("chargerId is required");
        }
        if (chargerIds.contains(chargerId)) {
            throw new IllegalArgumentException("Charger ID must be unique");
        }

        Charger charger = new Charger(chargerId, type, powerLevelKw);
        station.addCharger(charger);
        chargerIds.add(chargerId);
        return charger;
    }

    /**
     * US-O1.7: Read Charger Information
     */
    public Optional<Charger> getCharger(String chargerId) {
        for (ChargingStation station : stationsById.values()) {
            Charger c = station.getCharger(chargerId);
            if (c != null) {
                return Optional.of(c);
            }
        }
        return Optional.empty();
    }

    /**
     * US-O1.4: Update Chargers
     */
    public Charger updateCharger(String chargerId, ChargerType newType, Double newPowerLevel, ChargerStatus newStatus) {
        Charger charger = getCharger(chargerId)
                .orElseThrow(() -> new IllegalArgumentException("Charger not found"));

        if (newType != null) {
            charger.setType(newType);
        }
        if (newPowerLevel != null) {
            charger.setPowerLevelKw(newPowerLevel);
        }
        if (newStatus != null) {
            charger.setStatus(newStatus);
        }
        return charger;
    }

    /**
     * US-O1.6: Delete Chargers
     * - Only if no active or pending charging sessions
     */
    public boolean deleteCharger(String chargerId) {
        if (chargersWithActiveSessions.contains(chargerId)) {
            throw new IllegalStateException("Cannot delete charger with active or pending sessions");
        }

        for (ChargingStation station : stationsById.values()) {
            Charger removed = station.removeCharger(chargerId);
            if (removed != null) {
                chargerIds.remove(chargerId);
                return true;
            }
        }
        return false;
    }


    public void markChargerHasActiveSessions(String chargerId, boolean hasActive) {
        if (hasActive) {
            chargersWithActiveSessions.add(chargerId);
        } else {
            chargersWithActiveSessions.remove(chargerId);
        }
    }

    /**
     * US-C2.1: Search Charging Stations (by location text)
     * - Search results show location (name+address), type (AC/DC), current status.
     * Für Part1: Wir liefern eine einfache Aggregation zurück.
     */
    public List<StationSearchResult> searchStationsByText(String text) {
        String lower = text == null ? "" : text.toLowerCase();
        return stationsById.values()
                .stream()
                .filter(s -> s.getName().toLowerCase().contains(lower)
                        || s.getAddress().toLowerCase().contains(lower))
                .map(StationSearchResult::fromStation)
                .collect(Collectors.toList());
    }

    public static class StationSearchResult {
        public final String stationId;
        public final String name;
        public final String address;
        public final List<String> chargerSummaries;

        private StationSearchResult(String stationId, String name, String address, List<String> chargerSummaries) {
            this.stationId = stationId;
            this.name = name;
            this.address = address;
            this.chargerSummaries = chargerSummaries;
        }

        public static StationSearchResult fromStation(ChargingStation station) {
            List<String> summaries = station.getChargers().values().stream()
                    .map(c -> c.getChargerId() + " (" + c.getType() + ", " + c.getStatus() + ")")
                    .collect(Collectors.toList());
            return new StationSearchResult(
                    station.getStationId(),
                    station.getName(),
                    station.getAddress(),
                    summaries
            );
        }
    }
}