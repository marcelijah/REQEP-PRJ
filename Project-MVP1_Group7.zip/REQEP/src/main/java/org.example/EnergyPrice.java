package org.example;

public class EnergyPrice {

    private final double pricePerKwh;
    private final double pricePerMinute;

    public EnergyPrice(double pricePerKwh, double pricePerMinute) {
        if (pricePerKwh < 0 || pricePerMinute < 0) {
            throw new IllegalArgumentException("Prices must be non-negative");
        }
        this.pricePerKwh = pricePerKwh;
        this.pricePerMinute = pricePerMinute;
    }

    public double getPricePerKwh() {
        return pricePerKwh;
    }

    public double getPricePerMinute() {
        return pricePerMinute;
    }
}