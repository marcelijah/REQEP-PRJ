package org.example;

import java.util.List;

public class App {

    public static void main(String[] args) {
        // Management-Klassen initialisieren
        UserManager userManager = new UserManager();
        LocationManager locationManager = new LocationManager();
        PricingManager pricingManager = new PricingManager();
        ChargingSessionManager sessionManager = new ChargingSessionManager(locationManager, pricingManager);
        InvoiceManager invoiceManager = new InvoiceManager();

        // -----------------------------
        // 1. Client anlegen (EPIC C1)
        // -----------------------------
        Client client = userManager.createAccount(
                "Arian",
                "arian@sadeghian.com",
                "123"
        );
        client.setPrepaidBalance(100.0);

        System.out.println("=== CLIENT ===");
        System.out.println("Created client with ID: " + client.getCustomerId());
        System.out.println("Email: " + client.getEmail());
        System.out.println("Prepaid balance: " + client.getPrepaidBalance());
        System.out.println();

        // ------------------------------------------
        // 2. Station + Charger anlegen (EPIC O1)
        // ------------------------------------------
        ChargingStation station = locationManager.createStation(
                "City Center",
                "Main Street 1, 1010 Vienna"
        );

        Charger charger = locationManager.addChargerToStation(
                station.getStationId(),
                "CC-AC-1",
                ChargerType.AC,
                11.0
        );

        System.out.println("=== STATION & CHARGER ===");
        System.out.println("Station ID: " + station.getStationId());
        System.out.println("Station name: " + station.getName());
        System.out.println("Station address: " + station.getAddress());
        System.out.println("Charger ID: " + charger.getChargerId());
        System.out.println("Charger type: " + charger.getType());
        System.out.println("Charger status: " + charger.getStatus());
        System.out.println();

        // --------------------------------------
        // 3. Preise setzen (EPIC O2, AC-Preise)
        // --------------------------------------
        pricingManager.updateAcDcPrices(
                station.getStationId(),
                ChargerType.AC,
                0.5,   // 0.5 €/kWh
                0.1    // 0.1 €/Minute
        );

        System.out.println("=== PRICING ===");
        StationPricing pricing = pricingManager.getPricingForStation(station.getStationId());
        pricing.getEnergyPrice(ChargerType.AC).ifPresent(price -> {
            System.out.println("AC price per kWh: " + price.getPricePerKwh());
            System.out.println("AC price per minute: " + price.getPricePerMinute());
        });
        System.out.println();

        // -------------------------------------------------
        // 4. Ladesession starten & stoppen (C2.2 + O3)
        // -------------------------------------------------
        System.out.println("=== CHARGING SESSION ===");
        System.out.println("Starting session on charger CC-AC-1...");

        ChargingSession session = sessionManager.startSession(
                client,
                station.getStationId(),
                "CC-AC-1"
        );

        System.out.println("Session ID: " + session.getSessionId());
        System.out.println("Start time: " + session.getStartTime());
        System.out.println("Mode at start (type): " + session.getChargerTypeAtStart());
        System.out.println("Price at start per kWh: " + session.getPricePerKwhAtStart());
        System.out.println("Price at start per minute: " + session.getPricePerMinuteAtStart());

        // Simulierter Verbrauch: 20 kWh in 60 Minuten
        session = sessionManager.stopSession(
                session.getSessionId(),
                20.0,
                60
        );
        System.out.println("Session stopped.");
        System.out.println("Energy kWh: " + session.getEnergyKwh());
        System.out.println("Duration minutes: " + session.getDurationMinutes());
        System.out.println();

        // -----------------------------------------------
        // 5. Betrag berechnen & Guthaben abbuchen (C3)
        // -----------------------------------------------
        double amount = session.getEnergyKwh() * session.getPricePerKwhAtStart()
                + session.getDurationMinutes() * session.getPricePerMinuteAtStart();

        System.out.println("=== BILLING ===");
        System.out.println("Calculated amount: " + amount);

        client.deductFromPrepaidBalance(amount);
        System.out.println("New prepaid balance: " + client.getPrepaidBalance());
        System.out.println();

        // -----------------------------------------
        // 6. Invoice erzeugen (O4 + C3)
        // -----------------------------------------
        Invoice invoice = invoiceManager.createInvoice(session, amount);

        System.out.println("=== INVOICE ===");
        System.out.println("Invoice ID: " + invoice.getInvoiceId());
        System.out.println("Client ID: " + invoice.getClientId());
        System.out.println("Session ID: " + invoice.getSessionId());
        System.out.println("Amount: " + invoice.getAmount());
        System.out.println("Session start: " + invoice.getSessionStart());
        System.out.println("Session end: " + invoice.getSessionEnd());
        System.out.println();

        // Client-Sicht (C3.1)
        System.out.println("=== CLIENT INVOICES OVERVIEW ===");
        List<Invoice> clientInvoices = invoiceManager.getInvoicesForClient(client.getCustomerId());
        for (Invoice inv : clientInvoices) {
            System.out.println("Invoice " + inv.getInvoiceId()
                    + " | amount=" + inv.getAmount()
                    + " | sessionStart=" + inv.getSessionStart());
        }
        System.out.println();

        // -----------------------------------------
        // 7. Monitoring-Demo (O3)
        // -----------------------------------------
        System.out.println("=== STATION STATUS DASHBOARD ===");
        List<ChargingSessionManager.StationStatusSummary> dashboard =
                sessionManager.getStationStatusDashboard();
        for (ChargingSessionManager.StationStatusSummary s : dashboard) {
            System.out.println("Station " + s.name + " (" + s.stationId + ")");
            for (String chargerInfo : s.chargerStatuses) {
                System.out.println("  - " + chargerInfo);
            }
        }
        System.out.println();

        System.out.println("=== REALTIME WORKLOAD ===");
        List<ChargingSessionManager.StationWorkload> workload =
                sessionManager.getRealtimeWorkload();
        for (ChargingSessionManager.StationWorkload w : workload) {
            System.out.println("Station " + w.name
                    + " | chargers=" + w.totalChargers
                    + " | activeSessions=" + w.activeSessions
                    + " | utilization=" + w.utilization);
        }

        System.out.println();
        System.out.println("=== DEMO COMPLETE ===");
    }
}