package org.example;

public enum ChargerType {
    AC,
    DC
}