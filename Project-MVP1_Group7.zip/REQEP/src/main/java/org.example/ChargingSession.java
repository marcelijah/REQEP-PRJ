package org.example;

import java.time.LocalDateTime;
import java.util.List;

public class ChargingSession {

    private final String sessionId;
    private final String stationId;
    private final String chargerId;
    private final String clientId;
    private final LocalDateTime startTime;
    private LocalDateTime endTime;

    private final ChargerType chargerTypeAtStart;
    private final double pricePerKwhAtStart;
    private final double pricePerMinuteAtStart;
    private final List<DurationPriceRule> durationPriceRulesAtStart;

    private double energyKwh;
    private int durationMinutes;
    private boolean active;

    public ChargingSession(String sessionId,
                           String stationId,
                           String chargerId,
                           String clientId,
                           LocalDateTime startTime,
                           ChargerType chargerTypeAtStart,
                           double pricePerKwhAtStart,
                           double pricePerMinuteAtStart,
                           List<DurationPriceRule> durationPriceRulesAtStart) {

        this.sessionId = sessionId;
        this.stationId = stationId;
        this.chargerId = chargerId;
        this.clientId = clientId;
        this.startTime = startTime;
        this.chargerTypeAtStart = chargerTypeAtStart;
        this.pricePerKwhAtStart = pricePerKwhAtStart;
        this.pricePerMinuteAtStart = pricePerMinuteAtStart;
        this.durationPriceRulesAtStart = durationPriceRulesAtStart;
        this.active = true;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getStationId() {
        return stationId;
    }

    public String getChargerId() {
        return chargerId;
    }

    public String getClientId() {
        return clientId;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public ChargerType getChargerTypeAtStart() {
        return chargerTypeAtStart;
    }

    public double getPricePerKwhAtStart() {
        return pricePerKwhAtStart;
    }

    public double getPricePerMinuteAtStart() {
        return pricePerMinuteAtStart;
    }

    public List<DurationPriceRule> getDurationPriceRulesAtStart() {
        return durationPriceRulesAtStart;
    }

    public double getEnergyKwh() {
        return energyKwh;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public boolean isActive() {
        return active;
    }

    public void stop(LocalDateTime endTime, double energyKwh, int durationMinutes) {
        this.endTime = endTime;
        this.energyKwh = energyKwh;
        this.durationMinutes = durationMinutes;
        this.active = false;
    }
}