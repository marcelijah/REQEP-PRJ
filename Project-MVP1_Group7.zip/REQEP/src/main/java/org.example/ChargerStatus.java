package org.example;

public enum ChargerStatus {
    OPERATIONAL_FREE,
    OPERATIONAL_OCCUPIED,
    OUT_OF_ORDER
}