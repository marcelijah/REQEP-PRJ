package org.example;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ChargingStation {

    private final String stationId;
    private String name;
    private String address;
    private int version;
    private final Map<String, Charger> chargers = new HashMap<>();

    public ChargingStation(String stationId, String name, String address) {
        if (stationId == null || stationId.isBlank()) {
            throw new IllegalArgumentException("stationId is required");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("name is required");
        }
        if (address == null || address.isBlank()) {
            throw new IllegalArgumentException("address is required");
        }
        this.stationId = stationId;
        this.name = name;
        this.address = address;
        this.version = 1;
    }

    public String getStationId() {
        return stationId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("name is required");
        }
        this.name = name;
        this.version++;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (address == null || address.isBlank()) {
            throw new IllegalArgumentException("address is required");
        }
        this.address = address;
        this.version++;
    }

    public int getVersion() {
        return version;
    }

    public Map<String, Charger> getChargers() {
        return Collections.unmodifiableMap(chargers);
    }

    void addCharger(Charger charger) {
        chargers.put(charger.getChargerId(), charger);
    }

    Charger removeCharger(String chargerId) {
        return chargers.remove(chargerId);
    }

    Charger getCharger(String chargerId) {
        return chargers.get(chargerId);
    }

    private boolean hasActiveSessions;

    public boolean hasActiveSessions() {
        return hasActiveSessions;
    }

    public void setHasActiveSessions(boolean hasActiveSessions) {
        this.hasActiveSessions = hasActiveSessions;
    }
}

