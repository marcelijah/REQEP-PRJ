package org.example;

import java.util.Objects;

public class Charger {

    private final String chargerId;
    private ChargerType type;
    private double powerLevelKw;
    private ChargerStatus status;


    public Charger(String chargerId, ChargerType type, double powerLevelKw) {
        if (chargerId == null || chargerId.isBlank()) {
            throw new IllegalArgumentException("chargerId is required");
        }
        if (type == null) {
            throw new IllegalArgumentException("type is required");
        }
        if (powerLevelKw <= 0) {
            throw new IllegalArgumentException("powerLevelKw must be positive");
        }
        this.chargerId = chargerId;
        this.type = type;
        this.powerLevelKw = powerLevelKw;
        this.status = ChargerStatus.OPERATIONAL_FREE;
    }

    public String getChargerId() {
        return chargerId;
    }

    public ChargerType getType() {
        return type;
    }

    public void setType(ChargerType type) {
        if (type == null) throw new IllegalArgumentException("type is required");
        this.type = type;
    }

    public double getPowerLevelKw() {
        return powerLevelKw;
    }

    public void setPowerLevelKw(double powerLevelKw) {
        if (powerLevelKw <= 0) {
            throw new IllegalArgumentException("powerLevelKw must be positive");
        }
        this.powerLevelKw = powerLevelKw;
    }

    public ChargerStatus getStatus() {
        return status;
    }

    public void setStatus(ChargerStatus status) {
        if (status == null) throw new IllegalArgumentException("status is required");
        this.status = status;
    }

    private boolean hasActiveSessions;

    public boolean hasActiveSessions() {
        return hasActiveSessions;
    }

    public void setHasActiveSessions(boolean hasActiveSessions) {
        this.hasActiveSessions = hasActiveSessions;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Charger)) return false;
        Charger charger = (Charger) o;
        return chargerId.equals(charger.chargerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(chargerId);
    }
}