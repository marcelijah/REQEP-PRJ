package org.example;

public class App {

    public static void main(String[] args) {
        // Management-Klassen initialisieren
        UserManager userManager = new UserManager();
        LocationManager locationManager = new LocationManager();

        // 1. Client anlegen (EPIC C1)

        Client client = userManager.createAccount(
                "Arian",
                "arian@sadeghian.com",
                "123"
        );
        client.setPrepaidBalance(100.0);

        System.out.println("=== CLIENT ===");
        System.out.println("Created client with ID: " + client.getCustomerId());
        System.out.println("Email: " + client.getEmail());
        System.out.println("Prepaid balance: " + client.getPrepaidBalance());
        System.out.println();

        // 2. Station + Charger anlegen (EPIC O1)
        ChargingStation station = locationManager.createStation(
                "FH Technikum Vienna",
                "Höchstädtplatz 6, 1200 Vienna"
        );

        Charger charger = locationManager.addChargerToStation(
                station.getStationId(),
                "CC-AC-1",
                ChargerType.AC,
                11.0
        );

        System.out.println("=== STATION & CHARGER ===");
        System.out.println("Station ID: " + station.getStationId());
        System.out.println("Station name: " + station.getName());
        System.out.println("Station address: " + station.getAddress());
        System.out.println("Charger ID: " + charger.getChargerId());
        System.out.println("Charger type: " + charger.getType());
        System.out.println("Charger status: " + charger.getStatus());
        System.out.println();


        System.out.println();
        System.out.println("=== DEMO COMPLETE ===");
    }
}