package org.example;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class UserManager {

    private final Map<String, Client> clientsById = new HashMap<>();
    private final Map<String, String> clientIdByEmail = new HashMap<>();

    // US-C1.1: Create AccountRequired fields validatedAccount receives a unique customer ID
    public Client createAccount(String name, String email, String password) {
        if (name == null || name.isBlank()
                || email == null || email.isBlank()
                || password == null || password.isBlank()) {
            throw new IllegalArgumentException("All required fields must be provided");
        }

        if (clientIdByEmail.containsKey(email)) {
            throw new IllegalArgumentException("Email already in use");
        }

        String customerId = generateCustomerId();
        Client client = new Client(customerId, name, email, password);

        clientsById.put(customerId, client);
        clientIdByEmail.put(email, customerId);

        return client;
    }

    private String generateCustomerId() {
        // simple unique ID, can be replaced with sequence, etc.
        return "C-" + UUID.randomUUID();
    }

    // US-C1.2: Login
    //Correct credentials grant access
    //Wrong ones show an error (hier boolean, fÃ¼rs UI kannst du Fehlermeldung bauen)
    public boolean login(String email, String password) {
        if (!clientIdByEmail.containsKey(email)) {
            return false;
        }
        String clientId = clientIdByEmail.get(email);
        Client client = clientsById.get(clientId);
        return client.getPassword().equals(password);
    }

    // US-C1.3: Read Account Information
    public Optional<Client> getAccountById(String customerId) {
        return Optional.ofNullable(clientsById.get(customerId));
    }

    public Optional<Client> getAccountByEmail(String email) {
        String id = clientIdByEmail.get(email);
        if (id == null) return Optional.empty();
        return Optional.ofNullable(clientsById.get(id));
    }

    // US-C1.4: Update Account InformationUpdated data is saved only if all required fields pass validation.
    public Client updateAccount(String customerId, String newName, String newEmail, String newPassword) {
        Client client = clientsById.get(customerId);
        if (client == null) {
            throw new IllegalArgumentException("Client not found");
        }

        if (newName == null || newName.isBlank()
                || newEmail == null || newEmail.isBlank()
                || newPassword == null || newPassword.isBlank()) {
            throw new IllegalArgumentException("All required fields must be provided");
        }

        // Check email uniqueness (except for this client)
        String existingId = clientIdByEmail.get(newEmail);
        if (existingId != null && !existingId.equals(customerId)) {
            throw new IllegalArgumentException("Email already in use");
        }

        // Update email maps if changed
        if (!client.getEmail().equals(newEmail)) {
            clientIdByEmail.remove(client.getEmail());
            clientIdByEmail.put(newEmail, customerId);
        }

        client.setName(newName);
        client.setEmail(newEmail);
        client.setPassword(newPassword);
        return client;
    }

    //US-C1.5: Delete Account
    //only if user confirms deletion
    public boolean deleteAccount(String customerId, boolean confirmed) {
        if (!confirmed) {
            return false;
        }
        Client removed = clientsById.remove(customerId);
        if (removed != null) {
            clientIdByEmail.remove(removed.getEmail());
            return true;
        }
        return false;
    }
}