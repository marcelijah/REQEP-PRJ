package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.example.Client;
import org.example.UserManager;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

public class ClientAccountManagementSteps {

    private final UserManager userManager = new UserManager();

    private Client lastCreatedClient;
    private boolean lastLoginResult;
    private Exception lastException;

    private String tempName;
    private String tempEmail;
    private String tempPassword;

    private String emailForUpdate;
    private String emailForDeletion;


    // -------------------------------------------------------
    // Account anlegen
    // -------------------------------------------------------

    @Given("a client with name {string} and email {string} and password {string}")
    public void a_client_with_name_and_email_and_password(String name, String email, String password) {
        this.tempName = name;
        this.tempEmail = email;
        this.tempPassword = password;
    }

    @When("the client creates an account")
    public void the_client_creates_an_account() {
        try {
            lastCreatedClient = userManager.createAccount(tempName, tempEmail, tempPassword);
            lastException = null;
        } catch (Exception e) {
            lastCreatedClient = null;
            lastException = e;
        }
    }

    @Then("the account is created with a unique customer id")
    public void the_account_is_created_with_a_unique_customer_id() {
        assertNotNull(lastCreatedClient, "Account should have been created");
        assertNotNull(lastCreatedClient.getCustomerId(), "Customer ID must not be null");
        assertFalse(lastCreatedClient.getCustomerId().isBlank(), "Customer ID must not be blank");
    }

    @Then("the account can be retrieved by email {string}")
    public void the_account_can_be_retrieved_by_email(String email) {
        Optional<Client> found = userManager.getAccountByEmail(email);
        assertTrue(found.isPresent(), "Account should be retrievable by email " + email);
    }

    // -------------------------------------------------------
    // Duplicate Email verhindern
    // -------------------------------------------------------

    @Given("an existing client account with email {string}")
    public void an_existing_client_account_with_email(String email) {
        userManager.createAccount("Existing", email, "pwd123");
    }

    @When("another client tries to register with email {string}")
    public void another_client_tries_to_register_with_email(String email) {
        try {
            userManager.createAccount("Other", email, "pwd456");
            lastException = null;
        } catch (Exception e) {
            lastException = e;
        }
    }

    @Then("the registration should fail")
    public void the_registration_should_fail() {
        assertNotNull(lastException, "Registration should have failed but no exception was thrown");
    }

    // -------------------------------------------------------
    // Login (korrekt/falsch)
    // -------------------------------------------------------

    @Given("an existing client account with email {string} and password {string}")
    public void an_existing_client_account_with_email_and_password(String email, String password) {
        userManager.createAccount("ExistingLogin", email, password);
    }

    @When("the client logs in with email {string} and password {string}")
    public void the_client_logs_in_with_email_and_password(String email, String password) {
        lastLoginResult = userManager.login(email, password);
    }

    @Then("the login should be successful")
    public void the_login_should_be_successful() {
        assertTrue(lastLoginResult, "Login should be successful");
    }

    @Then("the login should fail")
    public void the_login_should_fail() {
        assertFalse(lastLoginResult, "Login should fail");
    }

    // -------------------------------------------------------
    // Account updaten
    // -------------------------------------------------------

    @Given("an existing client account with email {string} and password {string} for update")
    public void an_existing_client_account_with_email_and_password_for_update(String email, String password) {
        userManager.createAccount("ToUpdate", email, password);
        this.emailForUpdate = email;
    }

    @When("the client updates the name to {string} and email to {string} and password to {string}")
    public void the_client_updates_the_name_to_and_email_to_and_password_to(String newName, String newEmail, String newPassword) {
        Client original = userManager.getAccountByEmail(emailForUpdate)
                .orElseThrow(() -> new AssertionError("Original account for update not found"));

        try {
            userManager.updateAccount(original.getCustomerId(), newName, newEmail, newPassword);
            lastException = null;
        } catch (Exception e) {
            lastException = e;
        }
    }

    @Then("the updated account has email {string}")
    public void the_updated_account_has_email(String expectedEmail) {
        Optional<Client> updated = userManager.getAccountByEmail(expectedEmail);
        assertTrue(updated.isPresent(), "Updated account with email " + expectedEmail + " not found");
    }

    // -------------------------------------------------------
    // Account löschen
    // -------------------------------------------------------

    @Given("an existing client account with email {string} and password {string} for deletion")
    public void an_existing_client_account_with_email_and_password_for_deletion(String email, String password) {
        userManager.createAccount("ToDelete", email, password);
        this.emailForDeletion = email;
    }

    @When("the client confirms account deletion")
    public void the_client_confirms_account_deletion() {
        Client client = userManager.getAccountByEmail(emailForDeletion)
                .orElseThrow(() -> new AssertionError("Account for deletion not found"));

        boolean deleted = userManager.deleteAccount(client.getCustomerId(), true);
        assertTrue(deleted, "Deletion should return true");
    }

    @When("the client does not confirm account deletion")
    public void the_client_does_not_confirm_account_deletion() {
        Client client = userManager.getAccountByEmail(emailForDeletion)
                .orElseThrow(() -> new AssertionError("Account for deletion not found"));
        // false = nicht bestätigt
        boolean deleted = userManager.deleteAccount(client.getCustomerId(), false);
        // sollte NICHT gelöscht sein
        assertFalse(deleted, "Account should not be deleted without confirmation");
    }

    @Then("the account should no longer be retrievable")
    public void the_account_should_no_longer_be_retrievable() {
        Optional<Client> found = userManager.getAccountByEmail(emailForDeletion);
        assertTrue(found.isEmpty(), "Account should no longer be retrievable after deletion");
    }




}